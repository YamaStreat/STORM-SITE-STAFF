# STORM SYSTEM v1.2 — DM Mirror

## Nouveau : conversation DM miroir
- Tous les tickets et contestations restent en **DM côté joueur**.
- Le salon privé staff affiche **tout l’historique question/réponse dans l’ordre**.
- Quand le joueur écrit au bot en DM, son message apparaît automatiquement dans le salon staff.
- Quand un membre du staff **écrit normalement dans le salon ticket**, le bot transmet ce message au joueur en DM.
- Le bot ajoute **✅** sur le message staff quand l’envoi privé a réussi, et **❌** s’il échoue.
- Les pièces jointes sont relayées sous forme de liens Discord.
- `/reply` reste disponible mais n’est plus obligatoire.

Bot Discord prêt à lancer pour un serveur FiveM PVP.

## Fonctions incluses

- 🎫 **Tous les tickets en DM** : Support, Report joueur, Boutique, Partenariat, Recrutement staff. Le joueur ne voit aucun salon ticket sur le serveur.
- 🔨 **Contestation de ban en DM** : questionnaire privé, dossier staff automatique, accepter/refuser/demander une information.
- ✅ **Accusés de réception par réaction** : le bot met ✅ sur chaque réponse DM du joueur et sur les messages envoyés/confirmés.
- 💬 `/reply` : un staff répond au joueur en DM depuis son dossier.
- 🎁 Giveaways persistants avec réaction 🎉, fin automatique et `/reroll`.
- 📢 `/annonce` : annonces en embed STORM.
- 🔴 `/stream` : annonce manuelle Twitch/YouTube/Kick.
- 📋 Salon de logs créé automatiquement.
- ⚡ `/ping`.

## 1. Créer l'application Discord

1. Va sur le Discord Developer Portal.
2. Crée une application, puis un Bot.
3. Copie le **Token**.
4. Dans **Bot > Privileged Gateway Intents**, active uniquement :
   - Message Content Intent
5. Invite le bot avec les scopes `bot` + `applications.commands`.
6. Donne-lui au minimum : gérer les salons, voir/envoyer des messages, intégrer des liens, ajouter des réactions, gérer les messages.

## 2. Configuration

Copie `.env.example` vers `.env` et remplis :

```env
DISCORD_TOKEN=ton_token
CLIENT_ID=id_application
GUILD_ID=id_du_serveur
BOT_NAME=STORM SYSTEM
BOT_COLOR=2B7FFF
```

Pour afficher les IDs dans Discord : Paramètres > Avancés > Mode développeur.

## 3. Installation locale

Node.js 20 ou supérieur :

```bash
npm install
npm start
```

Quand le bot est connecté, lance dans Discord :

```text
/setup staff_role:@Staff panel_channel:#support
```

Le bot crée automatiquement :

- catégorie privée staff `🎫 STORM TICKETS`
- catégorie privée `🔨 BAN APPEALS`
- salon privé `#storm-logs`
- panel des tickets

## 4. Tickets 100 % en DM

1. Le joueur choisit **Support / Report / Boutique / Partenariat / Recrutement** dans le panel.
2. STORM SYSTEM ouvre immédiatement la conversation en **message privé**.
3. Le bot pose les questions adaptées au type de ticket.
4. Chaque réponse du joueur reçoit **✅**.
5. À la fin du questionnaire, un salon privé est créé **uniquement pour le staff**.
6. Le staff utilise `/reply message:...` dans ce salon : le joueur reçoit la réponse en DM.
7. Tout nouveau message envoyé par le joueur au bot est automatiquement transféré au staff jusqu’à la clôture du ticket.
8. Quand le staff clôture le ticket, le joueur est prévenu en DM.

## 5. Contestation de ban

1. Le joueur sélectionne **🔨 Contester un ban** dans le panel.
2. STORM SYSTEM lui envoie le questionnaire en **message privé**.
3. À chaque réponse reçue, le bot ajoute **✅** pour confirmer l'enregistrement.
4. Le dossier apparaît dans la catégorie privée BAN APPEALS.
5. Le staff peut cliquer :
   - ✅ Accepter
   - ❌ Refuser
   - 💬 Demander une info
   - 🔒 Clôturer
6. La décision est envoyée en privé au joueur et le message envoyé reçoit également **✅**.
7. `/reply message:...` permet de continuer la discussion avec le joueur depuis le salon staff.

## 6. Giveaways

Exemple :

```text
/giveaway salon:#giveaways duree:2h lot:VIP Gold 1 mois gagnants:1
```

Formats : `30s`, `10m`, `2h`, `1d`.

## 7. Annonces

```text
/annonce salon:#annonces titre:Mise à jour message:La nouvelle RedZone est disponible !
```

## 8. Streams

```text
/stream salon:#streams streamer:Samuel url:https://twitch.tv/exemple
```

La version fournie annonce les streams manuellement. Pour une détection automatique Twitch/YouTube, il faut ajouter les identifiants API de la plateforme.

## Hébergement

Commande de démarrage :

```text
npm start
```

Version Node recommandée : **20 ou 22**.

⚠️ Ne partage jamais ton fichier `.env` ni ton token Discord. Si un token est exposé, régénère-le immédiatement dans le Developer Portal.